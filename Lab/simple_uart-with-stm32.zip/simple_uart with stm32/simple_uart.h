#include <string>
#include "stm32f4xx_hal.h"

using namespace std;

class UARTChannel {
private:
	UART_HandleTypeDef* p2uart;
	uint16_t delay_time;

public:
	UARTChannel(UART_HandleTypeDef* _p2uart, uint16_t _delay_time);
	void tranString(string str);
	void tranInteger(int32_t num);
	void tranFloat(float num);
};
