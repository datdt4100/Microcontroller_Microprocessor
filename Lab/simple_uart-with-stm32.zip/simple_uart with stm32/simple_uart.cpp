#include "../Inc/simple_uart.h"

UARTChannel::UARTChannel(UART_HandleTypeDef* _p2uart, uint16_t _delay_time){
	this->p2uart = _p2uart;
	this->delay_time = _delay_time;
}

void UARTChannel::tranString(string str){
	uint8_t c[str.length()];
	for (uint8_t i=0; i<str.length(); i++)
		c[i] = str[i];
	HAL_UART_Transmit(this->p2uart, c, str.length(), this->delay_time);
}

void UARTChannel::tranInteger(int32_t num){
	string str = to_string(num);
	this->tranString(str);
}
void UARTChannel::tranFloat(float num){
	int count = 0;
	string dot = ".";
	while ((num-(int)num)!=0){
		num*=10;
		count++;
	}
	string data = std::to_string((int32_t)num);
	data.insert(data.length()-count,dot);
	this->tranString(data);
}
